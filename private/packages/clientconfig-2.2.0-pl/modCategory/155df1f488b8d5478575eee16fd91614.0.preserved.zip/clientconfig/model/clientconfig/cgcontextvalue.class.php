<?php
class cgContextValue extends xPDOSimpleObject {}