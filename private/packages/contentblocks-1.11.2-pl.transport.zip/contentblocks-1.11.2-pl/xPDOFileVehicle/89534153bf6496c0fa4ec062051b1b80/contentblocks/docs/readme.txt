--------------------------------------------
ContentBlocks - Building content better.
--------------------------------------------
Author: Mark Hamstra - support@modmore.com
--------------------------------------------

A revolutionary way of editing content in MODX Revolution.
