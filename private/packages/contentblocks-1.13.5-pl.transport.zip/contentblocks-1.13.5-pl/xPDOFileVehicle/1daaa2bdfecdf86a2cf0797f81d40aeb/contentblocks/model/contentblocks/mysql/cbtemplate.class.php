<?php
require_once (dirname(dirname(__FILE__)) . '/cbtemplate.class.php');
class cbTemplate_mysql extends cbTemplate {}