<?php
/**
 * Setting Lexicon Entries for easyCart
 *
 * @package LexiconEditor
 * @subpackage lexicon
 */
$_lang['setting_easycart.shop_id'] = 'Shop ID';
$_lang['setting_easycart.shop_id_desc'] = 'Shop ID';
$_lang['setting_easycart.api_key'] = 'API KEY';
$_lang['setting_easycart.api_key_desc'] = 'API KEY';
