<?php

/** Snippet properties */
$_lang['imageplus.imageplus.docid'] = 'Ressource d\'où provient la valeur de TV  Image+ .';
$_lang['imageplus.imageplus.options'] = 'Options étendues phpThumb pour l\'image.';
$_lang['imageplus.imageplus.tpl'] = 'Fragment de code (chunck) pour la sortie du snippet.';
$_lang['imageplus.imageplus.tvname'] = 'Nom de la TV Image+.';
$_lang['imageplus.imageplus.type'] = 'Type de la sortie du snippet. Peut être défini comme <i>vérifier</i> <i>tpl</i> ou <i>thumb</i>.';
