<?php
/** Translated by Alberto M. Rossi **/
$_lang['seopro.keywords'] = 'Parole chiave';
$_lang['seopro.characters'] = 'Caratteri';
$_lang['seopro.characters.allowed'] = 'Caratteri permessi';
$_lang['seopro.tips'] = 'Suggerimenti per SEO-PRO!';
$_lang['seopro.focuskeywords'] = 'Focus sulle parole chiave';
$_lang['seopro.focuskeywords_desc'] = 'Separate da virgole';
$_lang['seopro.prevbox'] = 'Come verrà visualizzato in Google?';
$_lang['seopro.prevbox_yandex'] = 'Come verrà visualizzato in Yandex?';
$_lang['seopro.emptymetadescription']='<i>Please enter a description</i>';
$_lang['seopro.branding_text']='This site is optimized with the Sterc seoPro plugin - https://github.com/Sterc/SEOPro.';
