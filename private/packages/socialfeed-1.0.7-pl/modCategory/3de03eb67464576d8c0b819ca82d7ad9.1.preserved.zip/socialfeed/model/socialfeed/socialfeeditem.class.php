<?php
/**
 * @package socialfeed
 */
class SocialFeedItem extends xPDOSimpleObject {}
?>