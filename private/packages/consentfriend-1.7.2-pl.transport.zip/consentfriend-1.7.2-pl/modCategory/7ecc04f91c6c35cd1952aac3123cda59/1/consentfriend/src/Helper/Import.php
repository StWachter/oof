<?php
/**
 * Import classfile
 *
 * @package consentfriend
 * @subpackage classfile
 */

namespace TreehillStudio\ConsentFriend\Helper;

use ConsentFriend;
use ConsentfriendPurposes;
use ConsentfriendServiceContexts;
use ConsentfriendServiceCountries;
use ConsentfriendServicePurposes;
use ConsentfriendServices;
use Exception;
use modContext;
use modSystemSetting;
use modX;
use PDO;
use xPDO;
use xPDOObject;

/**
 * Class ConsentFriend
 */
class Import extends ConsentFriend
{
    /**
     * A reference to the modX instance
     * @var modX $modx
     */
    public $modx;

    /**
     * Set purposes data.
     *
     * @param array $data
     * @param string $mode
     *
     * @throws Exception
     */
    public function setPurposes(array $data, string $mode)
    {
        foreach ($data as $row) {
            /** @var ConsentfriendPurposes $purpose */
            $purpose = null;
            if (($mode == 'append' || $mode == 'setup' || $mode == 'essential') && $this->modx->getObject('ConsentfriendPurposes', ['key' => $row['key']])) {
                continue;
            } elseif ($mode == 'update') {
                // Update existing purposes only in update mode
                $purpose = $this->modx->getObject('ConsentfriendPurposes', ['key' => $row['key']]);
            }
            if (!$purpose) {
                $purpose = $this->modx->newObject('ConsentfriendPurposes');
            }
            $purpose->fromArray($row, '', true);
            if (!$purpose->save()) {
                throw new Exception($this->modx->lexicon('consentfriend.purpose_err_importing_row', ['row' => $purpose->toJSON()]));
            }
        }
    }

    /**
     * Set services data.
     *
     * @param array $data
     * @param string $mode
     *
     * @throws Exception
     */
    public function setServices(array $data, string $mode)
    {
        foreach ($data as $row) {
            $type = 'existing';
            /** @var ConsentfriendServices $service */
            $service = null;
            if (($mode == 'append' || $mode == 'setup') && $this->modx->getObject('ConsentfriendServices', ['name' => $row['name']])) {
                continue;
            } elseif ($mode == 'update') {
                $service = $this->modx->getObject('ConsentfriendServices', ['name' => $row['name']]);
                $type = 'update';
            } elseif ($mode == 'essential') {
                if (!($row['essential'] ?? false)) {
                    continue;
                } else {
                    $service = $this->modx->getObject('ConsentfriendServices', ['name' => $row['name']]);
                    $type = 'update';
                }
            }
            if (!$service) {
                $service = $this->modx->newObject('ConsentfriendServices');
                $type = 'new';
            }
            $service->fromArray($row);
            if ($row['cookies'] ?? false) {
                $row['cookies'] = (is_array($row['cookies'])) ? json_encode($row['cookies']) : $row['cookies'];
                $service->set('cookies', $row['cookies']);
            } else {
                $service->set('cookies', '[]');
            }
            if (!isset($row['sortindex']) && !$service->get('sortindex')) {
                $service->set('sortindex', $this->modx->getCount('ConsentfriendServices'));
            }
            if (!$service->save()) {
                throw new Exception($this->modx->lexicon('consentfriend.service_err_importing_row', ['row' => $service->toJSON()]));
            }

            if ($type == 'update' || $type == 'new') {
                $purposes = ($row['purposes'] != '') ? explode(',', $row['purposes']) : [];
                if (!$this->handlePurposes($service, $purposes)) {
                    throw new Exception($this->modx->lexicon('consentfriend.service_err_importing_purposes', ['purposes' => implode(',', $purposes)]));
                }
                if ($this->getOption('useContexts')) {
                    $contexts = ($row['contexts'] != '') ? explode(',', $row['contexts']) : [];
                    if (!$this->handleContexts($service, $contexts)) {
                        throw new Exception($this->modx->lexicon('consentfriend.service_err_importing_contexts', ['contexts' => implode(',', $contexts)]));
                    }
                }
                if ($this->getOption('useGeoIP') && $this->geoip) {
                    $countries = ($row['required_countries'] != '') ? explode(',', $row['required_countries']) : [];
                    if (!$this->handleCountries($service, $countries)) {
                        throw new Exception($this->modx->lexicon('consentfriend.service_err_importing_countries', ['countries' => implode(',', $countries)]));
                    }
                }
            }
        }
    }

    /**
     * Set config data.
     *
     * @param array $data
     * @param string $mode
     *
     * @throws Exception
     */
    public function setConfig(array $data, string $mode)
    {
        foreach ($data as $key => $value) {
            /** @var modSystemSetting $setting */
            $setting = $this->modx->getObject('modSystemSetting', ['key' => 'consentfriend.' . $key]);
            if (!$setting || $mode == 'append') {
                // Don't create or append system settings
                continue;
            }
            if ($setting->get('value') != (string)$value) {
                // Don't update equal existing system setting values
                $value = $this->prepareValue($setting, $value);
                $setting->set('value', $value);
                if (!$setting->save()) {
                    throw new Exception($this->modx->lexicon('consentfriend.setting_err_importing_row', ['row' => $setting->toJSON()]));
                }
            }
        }
    }

    /**
     * Prepare the setting value on base of the setting xtype.
     *
     * @param xPDOObject $setting
     * @param $value
     * @return string
     */
    public function prepareValue(xPDOObject $setting, $value)
    {
        switch ($setting->get('xtype')) {
            case 'combo-boolean':
                $value = $value ? '1' : '0';
                break;
            case 'numberfield':
                $value = (string)$value;
                break;
        }

        return $value;
    }

    /**
     * Handle purpose to service assignments.
     *
     * @param xPDOObject $service
     * @param array $purposeKeys
     * @return bool
     */
    private function handlePurposes(xPDOObject $service, array $purposeKeys)
    {
        $purposeIds = [];
        $foundKeys = [];
        /** @var ConsentfriendPurposes[] $purposes */
        $purposes = $this->modx->getIterator('ConsentfriendPurposes', [
            'key:IN' => $purposeKeys
        ]);
        foreach ($purposes as $purpose) {
            $purposeIds[] = $purpose->get('id');
            $foundKeys[] = $purpose->get('key');
        }
        $notFoundKeys = array_diff($purposeKeys, $foundKeys);
        foreach ($notFoundKeys as $notFoundKey) {
            $purpose = $this->modx->newObject('ConsentfriendPurposes');
            $purpose->fromArray([
                'key' => $notFoundKey,
                'active' => true,
                'sortindex' => $this->modx->getCount('ConsentfriendPurposes') + 1
            ]);
            if (!$purpose->save()) {
                $this->modx->log(xPDO::LOG_LEVEL_ERROR, $this->modx->lexicon('consentfriend.service_err_purpose_save'));
                return false;
            } else {
                $purposeIds[] = $purpose->get('id');
            }
        }

        /** @var ConsentfriendServicePurposes[] $existingServicePurposes */
        $existingServicePurposes = $this->modx->getIterator('ConsentfriendServicePurposes', [
            'service_id' => $service->get('id')
        ]);
        foreach ($existingServicePurposes as $existingServicePurpose) {
            $purposeId = (string)$existingServicePurpose->get('purpose_id');
            if (!in_array($purposeId, $purposeIds)) {
                // Remove not assigned purpose ids
                if (!$existingServicePurpose->remove()) {
                    $this->modx->log(xPDO::LOG_LEVEL_ERROR, $this->modx->lexicon('consentfriend.service_err_servicepurpose_remove'));
                    return false;
                }
            } else {
                // Ignore assigned purpose ids
                $purposeIds = array_diff($purposeIds, [$purposeId]);
            }
        }
        // Add new purpose ids
        foreach ($purposeIds as $purposeId) {
            /** @var ConsentfriendPurposes $purpose */
            $purpose = $this->modx->getObject('ConsentfriendPurposes', [
                'id' => $purposeId
            ]);
            if ($purpose) {
                /** @var ConsentfriendServicePurposes $servicePurpose */
                $servicePurpose = $this->modx->newObject('ConsentfriendServicePurposes');
                $servicePurpose->fromArray([
                    'service_id' => $service->get('id'),
                    'purpose_id' => $purposeId
                ]);
                if (!$servicePurpose->save()) {
                    $this->modx->log(xPDO::LOG_LEVEL_ERROR, $this->modx->lexicon('consentfriend.service_err_servicepurpose_save'));
                    return false;
                }
            } else {
                $this->modx->log(xPDO::LOG_LEVEL_ERROR, $this->modx->lexicon('consentfriend.service_err_servicepurpose_nf'));
                return false;
            }
        }
        return true;
    }

    /**
     * Handle context to service assignments.
     *
     * @param xPDOObject $service
     * @param array $contextKeys
     * @return bool
     */
    private function handleContexts(xPDOObject $service, array $contextKeys)
    {
        /** @var ConsentfriendServiceContexts[] $existingServiceContexts */
        $existingServiceContexts = $this->modx->getIterator('ConsentfriendServiceContexts', [
            'service_id' => $service->get('id')
        ]);
        foreach ($existingServiceContexts as $existingServiceContext) {
            $contextKey = (string)$existingServiceContext->get('context_key');
            if (!in_array($contextKey, $contextKeys)) {
                // Remove not assigned context keys
                if (!$existingServiceContext->remove()) {
                    $this->modx->log(xPDO::LOG_LEVEL_ERROR, $this->modx->lexicon('consentfriend.service_err_servicecontext_remove'));
                    return false;
                }
            } else {
                // Ignore assigned context keys
                $contextKeys = array_diff($contextKeys, [$contextKey]);
            }
        }
        // Add new context keys
        foreach ($contextKeys as $contextKey) {
            /** @var modContext $context */
            $context = $this->modx->getObject('modContext', [
                'key' => $contextKey
            ]);
            if ($context) {
                /** @var ConsentfriendServiceContexts $serviceContext */
                $serviceContext = $this->modx->newObject('ConsentfriendServiceContexts');
                $serviceContext->fromArray([
                    'service_id' => $service->get('id'),
                    'context_key' => $contextKey
                ]);
                if (!$serviceContext->save()) {
                    $this->modx->log(xPDO::LOG_LEVEL_ERROR, $this->modx->lexicon('consentfriend.service_err_servicecontext_save'));
                    return false;
                }
            } else {
                $this->modx->log(xPDO::LOG_LEVEL_ERROR, $this->modx->lexicon('consentfriend.service_err_servicecontext_nf'));
                return false;
            }
        }
        return true;
    }

    /**
     * Handle country to service assignments.
     *
     * @param xPDOObject $service
     * @param array $countryKeys
     * @return bool
     */
    private function handleCountries(xPDOObject $service, array $countryIsos)
    {
        /** @var ConsentfriendServiceCountries[] $existingServiceCountries */
        $existingServiceCountries = $this->modx->getIterator('ConsentfriendServiceCountries', [
            'service_id' => $service->get('id')
        ]);
        foreach ($existingServiceCountries as $existingServiceCountry) {
            $countryIso = (string)$existingServiceCountry->get('country_iso');
            if (!in_array($countryIso, $countryIsos)) {
                // Remove not assigned country isos
                if (!$existingServiceCountry->remove()) {
                    $this->modx->log(xPDO::LOG_LEVEL_ERROR, $this->modx->lexicon('consentfriend.service_err_servicecountry_remove'));
                    return false;
                }
            } else {
                // Ignore assigned country isos
                $countryIsos = array_diff($countryIsos, [$countryIso]);
            }
        }
        // Add new country isos
        foreach ($countryIsos as $countryIso) {
                $serviceCountry = $this->modx->newObject('ConsentfriendServiceCountries');
                $serviceCountry->fromArray([
                    'service_id' => $service->get('id'),
                    'country_iso' => $countryIso
                ]);
                if (!$serviceCountry->save()) {
                    $this->modx->log(xPDO::LOG_LEVEL_ERROR, $this->modx->lexicon('consentfriend.service_err_servicecountry_save'));
                    return false;
                }
        }
        return true;
    }

    /**
     * Remove existing data.
     * @param string $type
     */
    public function removeData($type = 'all')
    {
        if ($type == 'all' || $type == 'purposes') {
            /** @var ConsentfriendPurposes[] $collection */
            $collection = $this->modx->getIterator('ConsentfriendPurposes');
            foreach ($collection as $item) {
                $item->remove();
            }
        }
        if ($type == 'all' || $type == 'services') {
            /** @var ConsentfriendServices[] $collection */
            $collection = $this->modx->getIterator('ConsentfriendServices');
            foreach ($collection as $item) {
                $item->remove();
            }
        }
    }

    /**
     * Clear the context and the lexicon topics cache.
     */
    protected function clearCache()
    {
        $query = $this->modx->newQuery('modContext');
        $query->select($this->modx->escape('key'));
        if ($query->prepare() && $query->stmt->execute()) {
            $contextKeys = $query->stmt->fetchAll(PDO::FETCH_COLUMN);
        } else {
            $contextKeys = [];
        }

        $this->modx->cacheManager->refresh(
            [
                'lexicon_topics' => [],
                'consentfriend' => [],
                'resource' => ['contexts' => array_diff($contextKeys, ['mgr'])],
                'system_settings' => []
            ]
        );
    }
}
