Changelog for Tower

Tower 1.0.0
---------------------------------
+ Initial Version