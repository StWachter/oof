<?php
/**
 * Setting Lexicon Entries for Tower
 *
 * @package tower
 * @subpackage lexicon
 */
$_lang['setting_tower.site_key'] = 'Site-Key';
$_lang['setting_tower.site_key_desc'] = 'Site-Key';
$_lang['setting_tower.ip_whitelist'] = 'IP-Whitelist';
$_lang['setting_tower.ip_whitelist_desc'] = 'Comma-separated list of IP addresses that are allowed to call the script.';
