<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'vxDelta',
    1 => 'vxDeltaEditor',
    2 => 'vxDeltaField',
  ),
  'xPDOObject' => 
  array (
    0 => 'vxResource',
    1 => 'vxTemplate',
    2 => 'vxChunk',
    3 => 'vxSnippet',
    4 => 'vxPlugin',
    5 => 'vxTemplateVar',
  ),
);