<?php

namespace modmore\VersionX\Fields;

class Text extends Field
{
    protected string $tpl = 'mgr/fields/text.tpl';
}