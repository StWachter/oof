Big Brother
-----------

A Google Analytics dashboard for MODX Revolution

INSTALL INSTRUCTIONS:

- Download & Install via MODx Package Manager
- Reload the page
- Go to the menu "Components" and select "Google Analytics"
- Follow the instructions to allow Google Analytics API via OAuth.

NOTES & CREDITS:

- The CMP uses Highcharts (www.highcharts.com) for the charts which require a license if you plan to use the plugin in a commercial website (CC3 license - <a href="www.highcharts.com/licence">www.highcharts.com/licence</a>)
- Inspired by the WP plugin by Carson McDonald : <a href="http://www.ioncannon.net/projects/google-analytics-dashboard-wordpress-widget/">http://www.ioncannon.net/projects/google-analytics-dashboard-wordpress-widget/</a>
- Original development by @lossendae

BUGS AND DEVELOPMENT

<a href="https://github.com/modmore/BigBrother">https://github.com/modmore/BigBrother</a>