<?php
require_once dirname(dirname(__FILE__)) . '/export.class.php';
/**
 * Class redConfigurationSetExportProcessor
 */
class redConfigurationSetExportProcessor extends RedactorExportProcessor
{
    public $classKey = 'redConfigurationSet';
}

return 'redConfigurationSetExportProcessor';
