
easyCart

Author: Jan Dähne <https://www.quadro-system.de>
Copyright 2020

Official Documentation: https://www.quadro-system.de/modx-extras/easycart/

Bugs and Feature Requests: https://github.com/jdaehne/modx-easyCart

Questions: http://forums.modx.com
