<?php
/**
 * pdoPage French Lexicon Entries for pdoPage
 *
 * @package pdotools
 * @subpackage lexicon
 * @language fr
 */
$_lang['pdopage_first'] = 'Première';
$_lang['pdopage_last'] = 'Dernière';
$_lang['pdopage_more'] = 'Charger plus';
$_lang['pdopage_page'] = 'page';
$_lang['pdopage_from'] = 'sur';
