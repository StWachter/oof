<?php
/**
 * pdoPage Italian Lexicon Entries for pdoArchive
 *
 * @package pdotools
 * @subpackage lexicon
 * @language it
 */
$_lang['pdoarchive_month_01'] = 'Gennaio';
$_lang['pdoarchive_month_02'] = 'Febbraio';
$_lang['pdoarchive_month_03'] = 'Marzo';
$_lang['pdoarchive_month_04'] = 'Aprile';
$_lang['pdoarchive_month_05'] = 'Maggio';
$_lang['pdoarchive_month_06'] = 'Giugno';
$_lang['pdoarchive_month_07'] = 'Luglio';
$_lang['pdoarchive_month_08'] = 'Agosto';
$_lang['pdoarchive_month_09'] = 'Settembre';
$_lang['pdoarchive_month_10'] = 'Ottobre';
$_lang['pdoarchive_month_11'] = 'Novembre';
$_lang['pdoarchive_month_12'] = 'Dicembre';
