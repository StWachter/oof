<?php
/**
 * pdoPage German Lexicon Entries for pdoPage
 *
 * @package pdotools
 * @subpackage lexicon
 * @language de
 */
$_lang['pdopage_first'] = 'Erste';
$_lang['pdopage_last'] = 'Letzte';
$_lang['pdopage_more'] = 'Laden';
$_lang['pdopage_page'] = 'Seite';
$_lang['pdopage_from'] = 'von';