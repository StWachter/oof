<?php
/**
 * BackupMODX
 *
 * Copyright 2015-2019 by Jan Dähne <thomas.jakobi@partout.info>
 *
 * @package backupmodx
 */

require_once dirname(dirname(__DIR__)) . '/vendor/autoload.php';

/**
 * Class BackupMODX
 */
class BackupMODX extends \BackupMODX\BackupMODX {}
