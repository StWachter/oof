<?php

class BackupMODX {


    /**
     * BackupMODX constructor
     *
     * @param MODX $modx A reference to the MODX instance.
     * @param array $options An array of options. Optional.
     */
     public function __construct(MODX $modx, array $config = array())
    {
        // init modx
        $this->modx = $modx;

        // config
        //$this->apikeyServer = $this->modx->getOption('backupmodx.lorem');
        //$max_execution_time = ini_get('max_execution_time');
    }


    // Backup Files
    public function backupFiles()
    {
        return 'Filename';
    }

    // Backup Database
    public function backupDatabase()
    {

    }

    // Get Backups
    public function getBackups()
    {

    }

    // Remove Backup
    public function removeBackup()
    {

    }

}
