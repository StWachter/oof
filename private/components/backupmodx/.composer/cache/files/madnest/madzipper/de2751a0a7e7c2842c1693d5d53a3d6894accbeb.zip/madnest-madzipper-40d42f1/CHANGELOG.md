# Changelog

## v1.1.0

By Dropping Laravel requirement, the package is now framework agnostic. It only requires certain Laravel components in order to work.

## v1.0.5

Adds Laravel 8 support.

## v1.0.4

Adds Laravel 7 support.

## v1.0.3

Introduces security fix thanks to @snoopysecurity

## v1.0.2

Adds Laravel 6 compatibility.
